class Station extends Thread {
    private final int stationId;
    Station(int stationId) { this.stationId = stationId; }
    public void run() {
        try {
            Thread.sleep(100L * stationId);
            System.out.println("Station " + stationId + " scanned " + (stationId * 10) + " scripts.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Station " + stationId + " interrupted.");
        }
    }
}
public class ScannerStations {
    public static void main(String[] args) throws InterruptedException {
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new Station(i + 1);
            stations[i].start();
        }
        for (Thread station : stations) station.join();
        System.out.println("All scanner stations completed.");
    }
}
